We have split our work into 2 different notebooks:
1. isCancerous classification.ipynb - includes analysis, data set 
preparation and model development to classify the isCancerous 
category

This notebook uses both CSV files 'data_labels_mainData.csv' & 
'data_labels_extraData.csv'. It also uses the images contained 
in the folder 'patch_images'

2. cellType classification.ipynb - includes analysis, data set 
preparation and model development to classify the cellType 
category

This notebook uses one CSV file 'data_labels_mainData.csv'. It 
also uses the images contained in the folder 'patch_images'
